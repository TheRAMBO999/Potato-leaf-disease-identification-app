package com.example.potatoes

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ops.ResizeOp
import org.tensorflow.lite.DataType
import java.io.FileInputStream
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

class ModelHelper(context: Context) {

    private val interpreter: Interpreter
    private val classLabels: List<String> = listOf(
        "Potato___Early_blight",
        "Potato___Late_blight",
        "Potato___healthy"
    )

    init {
        // Load the TensorFlow Lite model as a MappedByteBuffer
        val model = loadModelFile(context, "potato_disease_model.tflite")
        interpreter = Interpreter(model)
    }

    // Helper function to load model as MappedByteBuffer
    private fun loadModelFile(context: Context, modelFileName: String): MappedByteBuffer {
        val fileDescriptor = context.assets.openFd(modelFileName)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    // Function to run inference
    fun classifyImage(inputImage: Bitmap): String {
        // Preprocess the input image
        val imageProcessor = ImageProcessor.Builder()
            .add(ResizeOp(256, 256, ResizeOp.ResizeMethod.BILINEAR)) // Resize to 256x256
            .add(NormalizeOp(0f, 1f))  // Rescale pixel values from [0, 255] to [0, 1]
            .build()

        val tensorImage = TensorImage(DataType.FLOAT32)
        tensorImage.load(inputImage)

        val processedImage = imageProcessor.process(tensorImage)

        // Create a TensorBuffer to hold the output
        val outputBuffer = TensorBuffer.createFixedSize(intArrayOf(1, classLabels.size), DataType.FLOAT32)

        // Run the model
        interpreter.run(processedImage.buffer, outputBuffer.buffer.rewind())

        // Get the result
        val results = outputBuffer.floatArray

        // Find the class with the highest probability
        val maxIndex = results.indices.maxByOrNull { results[it] } ?: -1
        val classLabel = if (maxIndex != -1) classLabels[maxIndex] else "Unknown"

        return classLabel
    }
}
