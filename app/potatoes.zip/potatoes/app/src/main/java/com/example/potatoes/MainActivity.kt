package com.example.potatoes

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var modelHelper: ModelHelper
    private lateinit var imageView: ImageView
    private lateinit var textViewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        modelHelper = ModelHelper(this)
        imageView = findViewById(R.id.imageView)
        textViewResult = findViewById(R.id.textViewResult)
        val buttonSelectImage: Button = findViewById(R.id.buttonSelectImage)

        buttonSelectImage.setOnClickListener {
            // Start the image selection activity
            pickImageFromGallery.launch("image/*")
        }
    }

    private val pickImageFromGallery = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, uri)
            imageView.setImageBitmap(bitmap)
            val result = modelHelper.classifyImage(bitmap)
            textViewResult.text = "Classification result: $result"
            Log.d("ModelResult", "Classification result: $result")
        }
    }
}
